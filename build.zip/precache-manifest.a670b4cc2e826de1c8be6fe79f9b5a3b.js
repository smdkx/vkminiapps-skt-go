self.__precacheManifest = [
  {
    "revision": "900e95097d309607a174",
    "url": "/static/css/main.0ff0557f.chunk.css"
  },
  {
    "revision": "900e95097d309607a174",
    "url": "/static/js/main.becb4a04.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "5c91c04accd06de2eb05",
    "url": "/static/css/2.83ba3feb.chunk.css"
  },
  {
    "revision": "5c91c04accd06de2eb05",
    "url": "/static/js/2.35e460ac.chunk.js"
  },
  {
    "revision": "fd5e1033dd721e62a355be0e3756ce09",
    "url": "/static/media/img_plug_2.fd5e1033.png"
  },
  {
    "revision": "88097fff4b73704142dacbdace8b882c",
    "url": "/static/media/newbie.88097fff.svg"
  },
  {
    "revision": "ca7be403586b0c55a395b59e131aec35",
    "url": "/static/media/steep.ca7be403.svg"
  },
  {
    "revision": "e4b3b32d24c0d3aacd03f54f7ea187d6",
    "url": "/static/media/static.e4b3b32d.svg"
  },
  {
    "revision": "c5e0d1f815316945876b1faad8dc5546",
    "url": "/static/media/donut.c5e0d1f8.svg"
  },
  {
    "revision": "ce7c0953635ccfe2c6b7bc4369c205d7",
    "url": "/static/media/subscriber.ce7c0953.svg"
  },
  {
    "revision": "59138da3263309cf780d63bfe5fddace",
    "url": "/static/media/easterEgg.59138da3.svg"
  },
  {
    "revision": "356552eb3300365cdd2d12817d48c568",
    "url": "/static/media/star.356552eb.svg"
  },
  {
    "revision": "20d099c84075f20f20d9743bd531addc",
    "url": "/static/media/emoji_2.20d099c8.png"
  },
  {
    "revision": "73e3119ee1b51c6fc938a42ee8c31616",
    "url": "/static/media/emoji_1.73e3119e.png"
  },
  {
    "revision": "92ca5aa8fec2c9e72f8f1df74b4e6ea5",
    "url": "/static/media/emoji_3.92ca5aa8.png"
  },
  {
    "revision": "00e4fdcd6f3bcb43a29ccf7af6a34733",
    "url": "/static/media/emoji_4.00e4fdcd.png"
  },
  {
    "revision": "633a30ecd4fda9fb5a3a0b4bfac9ee1f",
    "url": "/static/media/emoji_5.633a30ec.png"
  },
  {
    "revision": "2f7f275357679bd382f98d75edcc3e23",
    "url": "/static/media/memoji.2f7f2753.png"
  },
  {
    "revision": "fd1eba62902240fe65de2f02108aac50",
    "url": "/static/media/img_plug_3.fd1eba62.png"
  },
  {
    "revision": "dc2270110644946fb2e296172fd14a25",
    "url": "/static/media/achievements.dc227011.png"
  },
  {
    "revision": "6a4af6aee325f674ab583bff4eadacb4",
    "url": "/static/media/practice_group_1.6a4af6ae.png"
  },
  {
    "revision": "9004f16321d5720647b28c3848399b48",
    "url": "/static/media/practice_group_2.9004f163.png"
  },
  {
    "revision": "3b70845801af94c35e4a11bd4e7d2b6f",
    "url": "/static/media/img_plug_1.3b708458.png"
  },
  {
    "revision": "260b1870a9a8a8270b07b5ba7a324d83",
    "url": "/index.html"
  }
];